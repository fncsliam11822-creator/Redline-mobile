REDLINE MOBILE — iPhone installable web app

This is a Progressive Web App (PWA), not an App Store app or Roblox exploit.
The controls are standalone interface previews and do not affect Roblox gameplay.

TO INSTALL ON IPHONE:
1. Upload the contents of this folder to a static HTTPS host (for example GitHub Pages).
2. Open the hosted URL in Safari on your iPhone.
3. Tap Share (the square with the up arrow).
4. Choose Add to Home Screen.
5. Enable Open as Web App if that option appears, then tap Add.

The service worker and offline cache require HTTPS (localhost also works for local development).
